﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Data;
using System.Linq.Expressions;

namespace DataEntity.Services.Interfaces
{
    public interface IDataService<C, T>
        where T : class
        where C : DbContext
    {
        List<T> GetAll(Expression<Func<T, bool>> predicate = null);
        T Get(Expression<Func<T, bool>> predicate = null);
        int Create(T entity);
        int Update(Expression<Func<T, bool>> predicate, T entity);
        int Delete(T entity);
    }
}
