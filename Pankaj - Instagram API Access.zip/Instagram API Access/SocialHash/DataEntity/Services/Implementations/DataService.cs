﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataEntity.Services.Interfaces;
using System.Data;
using System.Data.Entity;
using System.Linq.Expressions;

namespace DataEntity.Services.Implementations
{
    public class DataService<C, T> : IDataService<C, T>
        where T : class
        where C : DbContext
        
    {
        private readonly DbSet<T> _dbSet;
        private readonly C _dbContext;

        public DataService(
            C dbContext,
            DbSet<T> dbSet            
            )
        {
            this._dbSet = dbSet;
            this._dbContext = dbContext;
        }

        public List<T> GetAll(Expression<Func<T, bool>> predicate = null)
        {
            if(null == predicate)
                return _dbSet.ToList<T>();
            else
                return _dbSet.Where<T>(predicate).ToList<T>();
        }

        public T Get(Expression<Func<T, bool>> predicate = null)
        {
            return _dbSet.FirstOrDefault<T>(predicate);
        }

        public int Create(T entity)
        {
            try
            {
                using (var context = _dbContext)
                {
                    _dbSet.Add(entity);
                    _dbContext.SaveChanges();
                }
                return 1;
            }
            catch (Exception)
            {
                return -99;
            }
        }

        public int Update(Expression<Func<T, bool>> predicate, T entity)
        {
            try
            {
                using (var context = _dbContext)
                {
                    var currentEntity = _dbSet.FirstOrDefault<T>(predicate);
                    currentEntity = entity;
                    _dbContext.SaveChanges();
                }                
                return 1;
            }
            catch (Exception)
            {
                return -99;
            }
        }

        public int Delete(T entity)
        {
            try
            {
                using (var context = _dbContext)
                {
                    _dbSet.Remove(entity);
                    _dbContext.SaveChanges();
                }                
                return 1;
            }
            catch (Exception)
            {
                return -99;
            }
        }
        
    }
}
