﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SocialHash.StaticHelpers
{
    public class Dummy
    {
        public Dummy(int val, string name)
        {
            this.Value = val;
            this.Name = name;
        }

        public int Value { get; set; }

        public string Name { get; set; }
    }
}