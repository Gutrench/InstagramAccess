﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Mail;
using System.Web;

namespace SocialHash.StaticHelpers.Instagram
{
    public class InstaStatic
    {
        public static void NotifyAdminInvalidAccessToken()
        {
            var adminEmail = ConfigurationManager.AppSettings["adminEmail"];
            var fromEmail = ConfigurationManager.AppSettings["Email_From"];
            var smtp = ConfigurationManager.AppSettings["Email_Smtp"];

            var clientId = ConfigurationManager.AppSettings["Ins_ClientId"];
            var redirectUri = ConfigurationManager.AppSettings["Ins_RedirectUri"];
            string insLogin = string.Format("https://api.instagram.com/oauth/authorize/?client_id={0}&redirect_uri={1}&response_type=code&scope=public_content",
                                                clientId,
                                                redirectUri);

            MailMessage mail = new MailMessage(fromEmail, adminEmail);
            SmtpClient client = new SmtpClient();
            client.Port = 25;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.UseDefaultCredentials = false;
            client.Host = smtp;
            mail.Subject = "this is a test email.";
            mail.Body = "<div>"
                        + "<p>Access token for Instagram app has expired.</p>"
                        + "<p>Please click <a href='" + insLogin + "'>here</a> to generate new access token.</p>"
                        +@"</div>";
            mail.IsBodyHtml = true;
            client.Send(mail);
        }
    }
}