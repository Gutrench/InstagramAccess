﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SocialHash.StaticData
{
    public enum SocialMediaType
    {
        Instagram = 1,
        Twitter = 2
    }
}