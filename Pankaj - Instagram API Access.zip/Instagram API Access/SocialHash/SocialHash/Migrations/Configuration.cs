namespace SocialHash.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using SocialHash.Models.Generic;

    internal sealed class Configuration : DbMigrationsConfiguration<SocialHash.DAL.SocialHashContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(SocialHash.DAL.SocialHashContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            context.AccessCodes.AddOrUpdate(x => x.Id,
        new AccessCode() {SocialMediaId = 1, SocialMediaName = "Instagram" }        
        );
            //
        }
    }
}
