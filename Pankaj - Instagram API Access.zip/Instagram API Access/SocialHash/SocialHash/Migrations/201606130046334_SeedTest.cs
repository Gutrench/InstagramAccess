namespace SocialHash.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class SeedTest : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.AccessCodes",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        SocialMediaId = c.Int(nullable: false),
                        SocialMediaName = c.String(),
                        AccessCodeValue = c.String(maxLength: 500),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.AccessCodes");
        }
    }
}
