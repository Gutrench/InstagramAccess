﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using SocialHash.DAL;
using SocialHash.Models.Generic;
using SocialHash.Services.Implementations;
using SocialHash.Services.Interfaces;
using SocialHash.StaticData;
using SocialHash.StaticHelpers.Instagram;
using SocialHash.ViewModels.Instagram;


namespace SocialHash.Controllers
{
    public class InstagramApiController : Controller
    {
        private readonly IAccessCodeService _accessCodeService;
        private readonly IInsService _insService;
        
        public InstagramApiController()
        {
            var _socialHashContext = new SocialHashContext();
            var _accessCodeDbSet = _socialHashContext.AccessCodes;

            _accessCodeService = new AccessCodeService(
                _socialHashContext, 
                _accessCodeDbSet
                );

            _insService = new InsService(
                _socialHashContext,
                _accessCodeDbSet
                );
        }
        
        public ActionResult InstaLogin()
        {
            var instaId = Convert.ToInt32(SocialMediaType.Instagram);
            var accessCodeInfo = _accessCodeService.Get(x => x.SocialMediaId == instaId);
            var clientId = ConfigurationManager.AppSettings["Ins_ClientId"];
            var redirectUri = ConfigurationManager.AppSettings["Ins_RedirectUri"];
            
            
            string insLogin = string.Format("https://api.instagram.com/oauth/authorize/?client_id={0}&redirect_uri={1}&response_type=code&scope=public_content",
                                                clientId,
                                                redirectUri);
            if (null == accessCodeInfo || (null != accessCodeInfo && string.IsNullOrEmpty(accessCodeInfo.AccessCodeValue)))
                return Redirect(insLogin);
            else
                return RedirectToAction("HashtagContent");
            return View();
        }

        public ActionResult AccessCodeReceived()
        {
            var queryString = Request.QueryString;
            var authRequest = (WebRequest)HttpWebRequest.Create(
                               string.Format("https://api.instagram.com/oauth/access_token")
                             );
            authRequest.Method = "POST";
            var clientId = ConfigurationManager.AppSettings["Ins_ClientId"];
            var clientSecret = ConfigurationManager.AppSettings["Ins_ClientSecret"];
            var redirectUri = ConfigurationManager.AppSettings["Ins_RedirectUri"];
            var code = queryString["code"].ToString();
            var data = string.Format("client_id={0}&client_secret={1}&redirect_uri={2}&code={3}&grant_type=authorization_code", clientId, clientSecret, redirectUri, code);
            var encodedData = Encoding.UTF8.GetBytes(data);
            authRequest.ContentLength = encodedData.Length;
            using (var dataStream = authRequest.GetRequestStream())
            {
                dataStream.Write(encodedData, 0, encodedData.Length);
            }
            
            var authResponse = (WebResponse)authRequest.GetResponse();
            var result = "";
            using (var reader = new StreamReader(authResponse.GetResponseStream()))
            {
                result = reader.ReadToEnd();
            }

            if (result.ToLower().Contains("error_type"))
            {
                InstaStatic.NotifyAdminInvalidAccessToken();
            }

            dynamic authResult = JsonConvert.DeserializeObject(result);
            var access_token = Convert.ToString(authResult.access_token);

            var instaId = Convert.ToInt32(SocialMediaType.Instagram);
            var accessCodeInfo = _accessCodeService.Get(x => x.SocialMediaId == instaId);
            if (null == accessCodeInfo)
                _accessCodeService.Create(new AccessCode() 
                { 
                    SocialMediaId = Convert.ToInt32(SocialMediaType.Instagram), 
                    SocialMediaName = SocialMediaType.Instagram.ToString(), 
                    AccessCodeValue = access_token 
                });
            else
            {
                accessCodeInfo.AccessCodeValue = access_token;
                _accessCodeService.Update(x => x.Id == accessCodeInfo.Id, accessCodeInfo);
            }

            return RedirectToAction("HashtagContent");            
        }

        [HttpGet]
        public ActionResult HashtagContent()
        {
            var model = new InstaViewModel();
            return View(model);
        }

        [HttpPost]
        public ActionResult HashtagContent(InstaViewModel model)
        {
            var mediaItems = _insService.FindMediaBasedOnHashtag(model.HashtagToSearch);
            var embedHtml = new List<string>();
            try
            {
                mediaItems.ForEach(item =>
                {
                    var embedRequest = (WebRequest)HttpWebRequest.Create(string.Format("https://api.instagram.com/oembed?url={0}&omitscript=true", item.MediaUrl));
                    embedRequest.Method = "Get";

                    var embedResponse = embedRequest.GetResponse();
                    using (var stream = new StreamReader(embedResponse.GetResponseStream()))
                    {
                        var embedStream = stream.ReadToEnd();
                        dynamic embedInfo = JsonConvert.DeserializeObject(embedStream);
                        embedHtml.Add(Convert.ToString(embedInfo.html));
                    }
                });
            }
            catch (Exception)
            {
                
            }
            model.MediaContent = embedHtml;
            return View(model);
        }

    }
}
