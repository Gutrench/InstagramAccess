﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Helpers;
using System.Web.Http;
using System.Web.Mvc;
using Newtonsoft.Json.Linq;
using SocialHash.DAL;
using SocialHash.Services.Implementations;
using SocialHash.Services.Interfaces;
using SocialHash.StaticHelpers;

namespace SocialHash.Controllers.Api
{
    public class InsController : ApiController
    {
        
        private readonly IInsService _insService;

        public InsController()
        {
            var _socialHashContext = new SocialHashContext();
            var _accessCodeDbSet = _socialHashContext.AccessCodes;
            _insService = new InsService(_socialHashContext, _accessCodeDbSet);
        }
        
        [System.Web.Http.HttpGet]
        public HttpResponseMessage Hashtag(string hashtag)
        {
            var resultMedia = _insService.FindMediaBasedOnHashtag(hashtag);
            return new HttpResponseMessage()
            {
                Content = new StringContent(JArray.FromObject(resultMedia).ToString(), Encoding.UTF8, "application/json")
            };
            //return Ok(resultMedia);
        }

        
    }
}
