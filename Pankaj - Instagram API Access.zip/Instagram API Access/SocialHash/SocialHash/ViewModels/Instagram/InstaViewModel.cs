﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SocialHash.ViewModels.Instagram
{
    public class InstaViewModel
    {
        public InstaViewModel()
        {
            MediaContent = new List<string>();
        }
        public string HashtagToSearch { get; set; }
        public List<string> MediaContent { get; set; }
    }
}