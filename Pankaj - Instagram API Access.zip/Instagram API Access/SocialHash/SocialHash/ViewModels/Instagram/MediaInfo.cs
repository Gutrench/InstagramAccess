﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SocialHash.ViewModels.Instagram
{
    public class MediaInfo
    {
        public MediaInfo()
        {
            this.User = new UserInfo();
        }
        public int? CommentCount { get; set; }
        public int? LikeCount { get; set; }

        public string MediaUrl { get; set; }
        public string ImageUrl { get; set; }
        public string Caption { get; set; }

        public UserInfo User { get; set; }

        public class UserInfo
        {
            public string Username { get; set; }
            public string ProfilePicUrl { get; set; }
        }
    }
}