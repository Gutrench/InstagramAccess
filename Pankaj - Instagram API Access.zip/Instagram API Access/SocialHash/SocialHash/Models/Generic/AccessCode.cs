﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SocialHash.Models.Generic
{
    public class AccessCode
    {
        [Key]
        public int Id { get; set; }
        public int SocialMediaId { get; set; }
        public string SocialMediaName { get; set; }
        [MaxLength(500)]
        public string AccessCodeValue { get; set; }
    }
}