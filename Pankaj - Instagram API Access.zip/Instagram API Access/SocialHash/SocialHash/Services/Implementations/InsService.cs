﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using DataEntity.Services.Implementations;
using Newtonsoft.Json;
using SocialHash.DAL;
using SocialHash.Models.Generic;
using SocialHash.Services.Interfaces;
using SocialHash.StaticData;
using SocialHash.ViewModels.Instagram;

namespace SocialHash.Services.Implementations
{
    public class InsService : IInsService
    {
        private readonly SocialHashContext _context;
        private readonly DbSet<AccessCode> _accessCodes;
        private readonly IAccessCodeService _accessCodeService;

        public InsService(
            SocialHashContext context,
            DbSet<AccessCode> accessCodes
            )            
        {
            this._context = context;
            this._accessCodes = accessCodes;
            _accessCodeService = new AccessCodeService(_context, _accessCodes);
        }

        public List<MediaInfo> FindMediaBasedOnHashtag(string hashtag)
        {
            try
            {
                var instaId = Convert.ToInt32(SocialMediaType.Instagram);
                var accessCodeInfo = _context.AccessCodes.First<AccessCode>(x => x.SocialMediaId == instaId);
                var tagRequest = (WebRequest)HttpWebRequest.Create(string.Format("https://api.instagram.com/v1/tags/{0}/media/recent?access_token={1}&count=10", hashtag, accessCodeInfo.AccessCodeValue));

                tagRequest.Method = "GET";

                var tagResponse = (WebResponse)tagRequest.GetResponse();
                var tagResult = "";
                using (var tagStreamReader = new StreamReader(tagResponse.GetResponseStream()))
                {
                    tagResult = tagStreamReader.ReadToEnd();
                }

                dynamic tagData = JsonConvert.DeserializeObject(tagResult);
                var dataList = new List<dynamic>();
                dataList = tagData.data.ToObject(typeof(List<dynamic>));
                var shortLinkList = new List<string>();
                var mediaList = new List<MediaInfo>();
                foreach (var item in dataList)
                {
                    var mediaInfo = new MediaInfo()
                    {
                        CommentCount = item.comments.count,
                        LikeCount = item.likes.count,
                        MediaUrl = item.link,
                        ImageUrl = item.images.standard_resolution.url,
                        Caption = item.caption.text,
                        User = new MediaInfo.UserInfo()
                        {
                            ProfilePicUrl = item.user.profile_picture,
                            Username = item.user.username
                        }
                    };
                    mediaList.Add(mediaInfo);
                    shortLinkList.Add(Convert.ToString(item.link));
                }

                return mediaList;
            }
            catch (Exception)
            {
                return new List<MediaInfo>();
            }
        }
    }
}