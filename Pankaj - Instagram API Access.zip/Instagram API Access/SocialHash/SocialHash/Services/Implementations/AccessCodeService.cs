﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SocialHash.DAL;
using SocialHash.Models.Generic;
using SocialHash.Services.Interfaces;
using DataEntity.Services.Implementations;
using System.Data.Entity;
using SocialHash.ViewModels.Instagram;
using Newtonsoft.Json;
using System.IO;
using System.Net;
using SocialHash.StaticData;

namespace SocialHash.Services.Implementations
{
    public class AccessCodeService : DataService<SocialHashContext, AccessCode>, IAccessCodeService
    {
        private readonly SocialHashContext _context;
        private readonly DbSet<AccessCode> _accessCodeDbSet;

        public AccessCodeService(
            SocialHashContext context, 
            DbSet<AccessCode> accessCodeDbSet
            )
            :base(context, accessCodeDbSet)
        {
            this._context = new SocialHashContext();
        }

        
    }
}