﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataEntity.Services.Interfaces;
using SocialHash.DAL;
using SocialHash.Models.Generic;
using SocialHash.ViewModels.Instagram;

namespace SocialHash.Services.Interfaces
{
    public interface IInsService
    {
        List<MediaInfo> FindMediaBasedOnHashtag(string hashtag);
    }
}
